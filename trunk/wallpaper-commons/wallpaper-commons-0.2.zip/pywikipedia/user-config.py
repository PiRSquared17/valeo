# -*- coding: utf-8 -*-
ring_bell = False
minthrottle = 1
maxthrottle = 1
put_throttle = 1
noisysleep = 1.0
userinterface = 'terminal'
transliterate = True

mylang = 'commons'
family = 'commons'
usernames['commons']['commons'] = 'Guest'
